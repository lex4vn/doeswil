<div class="row">
   <div class="col-md-12">
      <div class="modal-footer footer">Copyright &copy;  <a href="http://www.digitalvidhya.com" target="_blank"><?php if(isset($site_data->copy_right)) echo $site_data->copy_right; ?></a>  - All Rights Reserved. </div>
   </div>
</div>
</div>
<div class="clearfix"></div>
</div>
</body>
</html>

