<div class="row">
   <div class="col-md-12">
      <div class="modal-footer footer">Copyright &copy;  <?php if(isset($site_data->copy_right)) echo $site_data->copy_right; ?> - All Rights Reserved. </div>
   </div>
</div>
</div>
<div class="clearfix"></div>
</div>
</body>
</html>

