<?php $this->load->view('temp/header'); ?>
<?php $this->load->view($content); ?>
<?php $this->load->view('temp/footer'); ?>