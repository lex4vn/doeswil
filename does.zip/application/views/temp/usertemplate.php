<?php $this->load->view('temp/userheader'); ?>
<?php $this->load->view('temp/userleftmenu'); ?>
<?php $this->load->view($content); ?>
<?php $this->load->view('temp/userfooter'); ?>