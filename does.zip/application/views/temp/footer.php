<!-- Footer-->
<div class="panel-footer padding">
   <div class="container-fluid footer">
      <div class="container">
         <div class="col-md-7"> <a href="<?php echo base_url(); ?>">Home</a> | <a href="<?php echo base_url(); ?>welcome/aboutus">About Us</a> | <a href="<?php echo base_url(); ?>welcome/contact">Contact Us</a> | <a href="<?php echo base_url(); ?>welcome/termsConditions">Terms of Use</a></div>
         <div class="col-md-5 rs-cha">
            <div class="social">
               <a href="https://www.facebook.com/Digitalvidhya" target="_blank"><i class="fa fa-facebook"></i></a>
               <a href="https://twitter.com/DigitalVidhya" target="_blank"><i class="fa fa-twitter"></i></a>
               <a href="https://plus.google.com/u/0/104552594436030794460/posts" target="_blank"><i class="fa fa-google-plus"></i></a>
            </div>
         </div>
      </div>
   </div>
   <div class="container-fluid copy">
      <div class="container padding">
         <div class="col-md-9">Copyright &copy;  <?php if(isset($site_data->copy_right)) echo $site_data->copy_right; ?>  All rights reserved.</div>
         <div class="col-md-3"> <a href="http://www.digitalvidhya.com" target="_blank"> Disigned By : Digital Vidhya </a></div>
      </div>
   </div>
</div>

<!-- Footer-->     
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo base_url();?>assets/designs/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo base_url();?>assets/designs/js/bootstrap.min.js"></script>

<script src="<?php echo base_url();?>assets/designs/js/html5placeholder.jquery.js"></script>

</body>

</html>

