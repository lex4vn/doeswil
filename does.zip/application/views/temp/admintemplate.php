<?php $this->load->view('temp/adminheader'); ?><?php $this->load->view('temp/adminleftmenu'); ?>
<?php $this->load->view($content); ?>
<?php $this->load->view('temp/adminfooter'); ?>