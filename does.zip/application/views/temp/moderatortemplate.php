<?php $this->load->view('temp/moderatorheader'); ?><?php $this->load->view('temp/moderatorleftmenu'); ?>
<?php $this->load->view($content); ?>
<?php $this->load->view('temp/moderatorfooter'); ?>